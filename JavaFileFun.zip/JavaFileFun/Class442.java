public class Class442{
	public static String getString(){
		return "";
	}
}


