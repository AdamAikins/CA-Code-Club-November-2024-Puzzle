public class Class295{
	public static String getString(){
		return "";
	}
}


