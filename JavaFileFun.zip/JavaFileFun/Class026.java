public class Class026{
	public static String getString(){
		return "";
	}
}


