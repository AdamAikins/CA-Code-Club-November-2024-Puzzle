public class Class038{
	public static String getString(){
		return "";
	}
}


