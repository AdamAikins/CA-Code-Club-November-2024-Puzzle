public class Class427{
	public static String getString(){
		return "";
	}
}


