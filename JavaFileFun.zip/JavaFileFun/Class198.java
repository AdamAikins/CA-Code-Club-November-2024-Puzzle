public class Class198{
	public static String getString(){
		return "";
	}
}


