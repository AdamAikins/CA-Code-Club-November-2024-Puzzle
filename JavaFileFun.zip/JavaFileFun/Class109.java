public class Class109{
	public static String getString(){
		return "";
	}
}


