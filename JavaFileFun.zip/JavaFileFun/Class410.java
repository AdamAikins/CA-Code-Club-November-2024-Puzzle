public class Class410{
	public static String getString(){
		return "";
	}
}


