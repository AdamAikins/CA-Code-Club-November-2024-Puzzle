public class Class019{
	public static String getString(){
		return "";
	}
}


