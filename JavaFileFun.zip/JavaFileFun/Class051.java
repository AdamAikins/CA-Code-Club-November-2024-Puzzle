public class Class051{
	public static String getString(){
		return "";
	}
}


