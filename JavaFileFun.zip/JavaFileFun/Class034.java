public class Class034{
	public static String getString(){
		return "";
	}
}


