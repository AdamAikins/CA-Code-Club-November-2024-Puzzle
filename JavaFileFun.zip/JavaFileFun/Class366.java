public class Class366{
	public static String getString(){
		return "";
	}
}


