public class Class330{
	public static String getString(){
		return "";
	}
}


