public class Class065{
	public static String getString(){
		return "";
	}
}


