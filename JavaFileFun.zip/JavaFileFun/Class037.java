public class Class037{
	public static String getString(){
		return "";
	}
}


