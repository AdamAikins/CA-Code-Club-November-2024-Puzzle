public class Class375{
	public static String getString(){
		return "";
	}
}


