public class Class440{
	public static String getString(){
		return "";
	}
}


