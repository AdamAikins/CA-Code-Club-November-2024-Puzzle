public class Class228{
	public static String getString(){
		return "";
	}
}


