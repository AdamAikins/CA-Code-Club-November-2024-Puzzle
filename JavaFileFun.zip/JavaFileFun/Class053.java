public class Class053{
	public static String getString(){
		return "";
	}
}


