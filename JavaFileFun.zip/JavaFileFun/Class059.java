public class Class059{
	public static String getString(){
		return "";
	}
}


