public class Class341{
	public static String getString(){
		return "";
	}
}


