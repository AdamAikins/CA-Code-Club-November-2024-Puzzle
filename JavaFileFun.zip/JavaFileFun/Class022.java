public class Class022{
	public static String getString(){
		return "";
	}
}


