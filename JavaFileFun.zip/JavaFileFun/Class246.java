public class Class246{
	public static String getString(){
		return "";
	}
}


