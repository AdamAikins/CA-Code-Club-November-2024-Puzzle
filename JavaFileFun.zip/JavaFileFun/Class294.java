public class Class294{
	public static String getString(){
		return "";
	}
}


