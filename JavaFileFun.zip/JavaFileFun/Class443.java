public class Class443{
	public static String getString(){
		return "";
	}
}


