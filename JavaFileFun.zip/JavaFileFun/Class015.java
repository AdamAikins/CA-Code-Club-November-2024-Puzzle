public class Class015{
	public static String getString(){
		return "";
	}
}


