public class Class238{
	public static String getString(){
		return "";
	}
}


