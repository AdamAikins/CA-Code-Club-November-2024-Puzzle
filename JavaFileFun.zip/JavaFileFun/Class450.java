public class Class450{
	public static String getString(){
		return "";
	}
}


