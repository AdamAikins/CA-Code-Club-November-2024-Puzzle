public class Class157{
	public static String getString(){
		return "";
	}
}


