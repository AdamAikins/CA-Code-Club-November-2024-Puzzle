public class Class362{
	public static String getString(){
		return "";
	}
}


