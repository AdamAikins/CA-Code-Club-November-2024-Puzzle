public class Class049{
	public static String getString(){
		return "";
	}
}


