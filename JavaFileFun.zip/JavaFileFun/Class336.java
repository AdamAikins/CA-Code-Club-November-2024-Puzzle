public class Class336{
	public static String getString(){
		return "";
	}
}


