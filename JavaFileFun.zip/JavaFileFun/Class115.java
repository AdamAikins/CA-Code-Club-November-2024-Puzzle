public class Class115{
	public static String getString(){
		return "";
	}
}


