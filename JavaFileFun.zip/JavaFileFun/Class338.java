public class Class338{
	public static String getString(){
		return "";
	}
}


