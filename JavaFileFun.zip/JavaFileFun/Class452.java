public class Class452{
	public static String getString(){
		return "";
	}
}


