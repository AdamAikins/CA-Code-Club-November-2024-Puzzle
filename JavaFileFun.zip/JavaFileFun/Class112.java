public class Class112{
	public static String getString(){
		return "";
	}
}


