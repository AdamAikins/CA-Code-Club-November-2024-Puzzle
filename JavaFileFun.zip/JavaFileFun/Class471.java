public class Class471{
	public static String getString(){
		return "";
	}
}


