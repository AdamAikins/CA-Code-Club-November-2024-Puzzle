public class Class165{
	public static String getString(){
		return "";
	}
}


