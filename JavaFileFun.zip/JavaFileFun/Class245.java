public class Class245{
	public static String getString(){
		return "";
	}
}


