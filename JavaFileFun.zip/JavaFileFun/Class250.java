public class Class250{
	public static String getString(){
		return "";
	}
}


