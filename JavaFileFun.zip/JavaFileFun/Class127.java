public class Class127{
	public static String getString(){
		return "";
	}
}


