public class Class081{
	public static String getString(){
		return "";
	}
}


