public class Class044{
	public static String getString(){
		return "";
	}
}


