public class Class116{
	public static String getString(){
		return "";
	}
}


