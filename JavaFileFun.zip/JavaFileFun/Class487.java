public class Class487{
	public static String getString(){
		return "";
	}
}


