public class Class477{
	public static String getString(){
		return "";
	}
}


