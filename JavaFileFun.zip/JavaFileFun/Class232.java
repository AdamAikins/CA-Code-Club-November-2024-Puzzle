public class Class232{
	public static String getString(){
		return "";
	}
}


