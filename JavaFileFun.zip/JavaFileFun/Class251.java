public class Class251{
	public static String getString(){
		return "";
	}
}


