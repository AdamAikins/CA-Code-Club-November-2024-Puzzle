public class Class324{
	public static String getString(){
		return "";
	}
}


