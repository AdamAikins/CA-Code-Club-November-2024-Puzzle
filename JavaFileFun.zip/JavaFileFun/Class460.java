public class Class460{
	public static String getString(){
		return "";
	}
}


