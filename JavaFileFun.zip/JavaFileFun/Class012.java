public class Class012{
	public static String getString(){
		return "";
	}
}


