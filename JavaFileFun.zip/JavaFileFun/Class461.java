public class Class461{
	public static String getString(){
		return "";
	}
}


