public class Class339{
	public static String getString(){
		return "";
	}
}


