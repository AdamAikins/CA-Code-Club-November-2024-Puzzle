public class Class193{
	public static String getString(){
		return "";
	}
}


