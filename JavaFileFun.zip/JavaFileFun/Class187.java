public class Class187{
	public static String getString(){
		return "";
	}
}


