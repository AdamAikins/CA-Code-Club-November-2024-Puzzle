public class Class405{
	public static String getString(){
		return "";
	}
}


