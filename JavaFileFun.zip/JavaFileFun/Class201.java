public class Class201{
	public static String getString(){
		return "";
	}
}


