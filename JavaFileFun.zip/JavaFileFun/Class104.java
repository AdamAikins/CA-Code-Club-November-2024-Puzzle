public class Class104{
	public static String getString(){
		return "";
	}
}


