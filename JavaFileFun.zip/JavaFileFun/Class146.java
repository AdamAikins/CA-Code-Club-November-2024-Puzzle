public class Class146{
	public static String getString(){
		return "";
	}
}


