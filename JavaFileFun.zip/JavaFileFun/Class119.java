public class Class119{
	public static String getString(){
		return "";
	}
}


