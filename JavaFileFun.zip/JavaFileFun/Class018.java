public class Class018{
	public static String getString(){
		return "";
	}
}


