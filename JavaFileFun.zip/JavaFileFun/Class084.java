public class Class084{
	public static String getString(){
		return "";
	}
}


