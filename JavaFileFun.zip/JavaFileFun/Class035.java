public class Class035{
	public static String getString(){
		return "";
	}
}


