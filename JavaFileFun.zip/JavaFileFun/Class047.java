public class Class047{
	public static String getString(){
		return "";
	}
}


