public class Class048{
	public static String getString(){
		return "";
	}
}


