public class Class007{
	public static String getString(){
		return "";
	}
}


