public class Class213{
	public static String getString(){
		return "";
	}
}


