public class Class380{
	public static String getString(){
		return "";
	}
}


