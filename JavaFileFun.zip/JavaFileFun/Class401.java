public class Class401{
	public static String getString(){
		return "";
	}
}


