public class Class192{
	public static String getString(){
		return "";
	}
}


