public class Class430{
	public static String getString(){
		return "";
	}
}


