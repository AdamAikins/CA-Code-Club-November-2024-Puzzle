public class Class010{
	public static String getString(){
		return "";
	}
}


