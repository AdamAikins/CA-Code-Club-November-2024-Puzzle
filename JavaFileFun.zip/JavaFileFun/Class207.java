public class Class207{
	public static String getString(){
		return "";
	}
}


