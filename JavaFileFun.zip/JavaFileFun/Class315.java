public class Class315{
	public static String getString(){
		return "";
	}
}


