public class Class162{
	public static String getString(){
		return "";
	}
}


