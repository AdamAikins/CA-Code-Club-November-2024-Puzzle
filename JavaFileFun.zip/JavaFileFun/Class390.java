public class Class390{
	public static String getString(){
		return "";
	}
}


