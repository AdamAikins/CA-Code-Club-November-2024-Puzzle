public class Class189{
	public static String getString(){
		return "";
	}
}


