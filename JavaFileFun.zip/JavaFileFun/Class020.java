public class Class020{
	public static String getString(){
		return "";
	}
}


