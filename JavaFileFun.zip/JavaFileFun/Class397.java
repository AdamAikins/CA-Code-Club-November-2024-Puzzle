public class Class397{
	public static String getString(){
		return "";
	}
}


