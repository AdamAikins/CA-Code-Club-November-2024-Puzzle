public class Class097{
	public static String getString(){
		return "";
	}
}


