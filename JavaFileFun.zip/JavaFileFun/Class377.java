public class Class377{
	public static String getString(){
		return "";
	}
}


