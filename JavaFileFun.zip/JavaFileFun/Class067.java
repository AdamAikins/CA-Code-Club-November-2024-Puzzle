public class Class067{
	public static String getString(){
		return "";
	}
}


