public class Class332{
	public static String getString(){
		return "";
	}
}


