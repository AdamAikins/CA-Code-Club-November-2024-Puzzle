public class Class033{
	public static String getString(){
		return "";
	}
}


