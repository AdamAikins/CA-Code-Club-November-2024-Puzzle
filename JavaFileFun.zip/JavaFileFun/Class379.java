public class Class379{
	public static String getString(){
		return "";
	}
}


