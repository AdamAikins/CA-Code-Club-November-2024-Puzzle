public class Class197{
	public static String getString(){
		return "";
	}
}


