public class Class265{
	public static String getString(){
		return "";
	}
}


