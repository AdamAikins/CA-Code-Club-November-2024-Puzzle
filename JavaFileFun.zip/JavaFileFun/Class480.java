public class Class480{
	public static String getString(){
		return "";
	}
}


