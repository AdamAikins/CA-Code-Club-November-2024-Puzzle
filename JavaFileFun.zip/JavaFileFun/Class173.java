public class Class173{
	public static String getString(){
		return "";
	}
}


