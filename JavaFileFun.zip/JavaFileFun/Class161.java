public class Class161{
	public static String getString(){
		return "";
	}
}


