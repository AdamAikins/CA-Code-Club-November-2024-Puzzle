public class Class438{
	public static String getString(){
		return "";
	}
}


