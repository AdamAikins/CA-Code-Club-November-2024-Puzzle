public class Class117{
	public static String getString(){
		return "";
	}
}


