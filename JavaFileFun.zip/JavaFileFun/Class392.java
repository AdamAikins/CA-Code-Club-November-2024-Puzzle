public class Class392{
	public static String getString(){
		return "";
	}
}


