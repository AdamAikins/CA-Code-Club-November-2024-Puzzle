public class Class263{
	public static String getString(){
		return "";
	}
}


