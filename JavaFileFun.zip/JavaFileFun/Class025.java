public class Class025{
	public static String getString(){
		return "";
	}
}


