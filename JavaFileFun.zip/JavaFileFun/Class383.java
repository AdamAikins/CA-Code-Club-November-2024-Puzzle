public class Class383{
	public static String getString(){
		return "";
	}
}


