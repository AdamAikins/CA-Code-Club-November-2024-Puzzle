public class Class208{
	public static String getString(){
		return "";
	}
}


