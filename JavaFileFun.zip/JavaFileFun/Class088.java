public class Class088{
	public static String getString(){
		return "";
	}
}


