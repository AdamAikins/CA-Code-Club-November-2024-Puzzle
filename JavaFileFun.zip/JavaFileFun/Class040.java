public class Class040{
	public static String getString(){
		return "";
	}
}


