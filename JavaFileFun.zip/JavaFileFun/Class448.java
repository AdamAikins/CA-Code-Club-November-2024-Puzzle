public class Class448{
	public static String getString(){
		return "";
	}
}


