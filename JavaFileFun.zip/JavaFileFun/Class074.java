public class Class074{
	public static String getString(){
		return "";
	}
}


