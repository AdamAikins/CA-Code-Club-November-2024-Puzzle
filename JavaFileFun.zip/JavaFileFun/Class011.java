public class Class011{
	public static String getString(){
		return "";
	}
}


