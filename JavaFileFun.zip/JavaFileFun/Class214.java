public class Class214{
	public static String getString(){
		return "";
	}
}


