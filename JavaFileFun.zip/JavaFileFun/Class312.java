public class Class312{
	public static String getString(){
		return "";
	}
}


