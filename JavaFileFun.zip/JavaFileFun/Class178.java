public class Class178{
	public static String getString(){
		return "";
	}
}


