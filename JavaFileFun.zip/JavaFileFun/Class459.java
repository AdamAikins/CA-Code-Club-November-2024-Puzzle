public class Class459{
	public static String getString(){
		return "";
	}
}


