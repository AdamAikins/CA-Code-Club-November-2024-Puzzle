public class Class223{
	public static String getString(){
		return "";
	}
}


