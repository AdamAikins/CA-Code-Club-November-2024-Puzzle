public class Class415{
	public static String getString(){
		return "";
	}
}


