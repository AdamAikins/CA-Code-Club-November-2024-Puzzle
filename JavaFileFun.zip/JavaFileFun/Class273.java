public class Class273{
	public static String getString(){
		return "";
	}
}


