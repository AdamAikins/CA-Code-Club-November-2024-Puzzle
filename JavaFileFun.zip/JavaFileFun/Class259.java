public class Class259{
	public static String getString(){
		return "";
	}
}


