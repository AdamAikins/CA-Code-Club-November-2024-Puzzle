public class Class243{
	public static String getString(){
		return "";
	}
}


