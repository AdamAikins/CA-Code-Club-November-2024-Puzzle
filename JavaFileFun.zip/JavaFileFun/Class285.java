public class Class285{
	public static String getString(){
		return "";
	}
}


