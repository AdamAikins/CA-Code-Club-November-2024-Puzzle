public class Class068{
	public static String getString(){
		return "";
	}
}


