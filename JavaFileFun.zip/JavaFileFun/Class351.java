public class Class351{
	public static String getString(){
		return "";
	}
}


