public class Class381{
	public static String getString(){
		return "";
	}
}


