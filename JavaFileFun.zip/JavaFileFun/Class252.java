public class Class252{
	public static String getString(){
		return "";
	}
}


