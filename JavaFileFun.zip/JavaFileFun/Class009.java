public class Class009{
	public static String getString(){
		return "";
	}
}


