public class Class378{
	public static String getString(){
		return "";
	}
}


