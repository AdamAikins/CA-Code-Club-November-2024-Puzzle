public class Class456{
	public static String getString(){
		return "";
	}
}


