public class Class473{
	public static String getString(){
		return "";
	}
}


