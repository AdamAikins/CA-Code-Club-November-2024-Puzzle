public class Class155{
	public static String getString(){
		return "";
	}
}


