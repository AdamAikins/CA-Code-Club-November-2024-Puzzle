public class Class395{
	public static String getString(){
		return "";
	}
}


