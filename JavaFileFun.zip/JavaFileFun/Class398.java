public class Class398{
	public static String getString(){
		return "";
	}
}


