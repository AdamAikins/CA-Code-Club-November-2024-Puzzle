public class Class062{
	public static String getString(){
		return "";
	}
}


