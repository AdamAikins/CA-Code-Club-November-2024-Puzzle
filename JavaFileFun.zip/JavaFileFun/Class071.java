public class Class071{
	public static String getString(){
		return "";
	}
}


