public class Class474{
	public static String getString(){
		return "";
	}
}


