public class Class268{
	public static String getString(){
		return "";
	}
}


