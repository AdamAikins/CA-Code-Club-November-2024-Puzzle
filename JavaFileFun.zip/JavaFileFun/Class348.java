public class Class348{
	public static String getString(){
		return "";
	}
}


