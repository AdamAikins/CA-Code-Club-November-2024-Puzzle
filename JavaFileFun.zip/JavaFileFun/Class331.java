public class Class331{
	public static String getString(){
		return "";
	}
}


