public class Class249{
	public static String getString(){
		return "";
	}
}


