public class Class457{
	public static String getString(){
		return "";
	}
}


