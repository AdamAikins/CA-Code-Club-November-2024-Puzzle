public class Class203{
	public static String getString(){
		return "";
	}
}


