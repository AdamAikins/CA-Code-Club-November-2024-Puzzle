public class Class046{
	public static String getString(){
		return "";
	}
}


