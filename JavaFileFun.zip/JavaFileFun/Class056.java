public class Class056{
	public static String getString(){
		return "";
	}
}


