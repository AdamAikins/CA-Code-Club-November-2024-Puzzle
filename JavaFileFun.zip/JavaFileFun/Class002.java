public class Class002{
	public static String getString(){
		return "";
	}
}


