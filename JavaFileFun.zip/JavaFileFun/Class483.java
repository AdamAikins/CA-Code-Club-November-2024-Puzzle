public class Class483{
	public static String getString(){
		return "";
	}
}


