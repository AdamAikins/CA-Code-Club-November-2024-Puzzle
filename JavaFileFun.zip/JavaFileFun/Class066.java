public class Class066{
	public static String getString(){
		return "";
	}
}


