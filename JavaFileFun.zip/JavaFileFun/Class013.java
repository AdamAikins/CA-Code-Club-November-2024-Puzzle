public class Class013{
	public static String getString(){
		return "";
	}
}


