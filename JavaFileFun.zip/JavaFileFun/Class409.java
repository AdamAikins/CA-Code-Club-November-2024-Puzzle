public class Class409{
	public static String getString(){
		return "";
	}
}


