public class Class244{
	public static String getString(){
		return "";
	}
}


