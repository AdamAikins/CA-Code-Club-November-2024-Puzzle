public class Class266{
	public static String getString(){
		return "";
	}
}


