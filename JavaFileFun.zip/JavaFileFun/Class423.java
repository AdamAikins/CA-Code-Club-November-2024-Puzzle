public class Class423{
	public static String getString(){
		return "";
	}
}


