public class Class219{
	public static String getString(){
		return "";
	}
}


