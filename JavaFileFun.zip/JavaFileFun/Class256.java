public class Class256{
	public static String getString(){
		return "";
	}
}


