public class Class387{
	public static String getString(){
		return "";
	}
}


