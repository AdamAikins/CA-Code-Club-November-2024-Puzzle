public class Class328{
	public static String getString(){
		return "";
	}
}


