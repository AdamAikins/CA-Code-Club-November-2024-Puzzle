public class Class177{
	public static String getString(){
		return "";
	}
}


