public class Class413{
	public static String getString(){
		return "";
	}
}


