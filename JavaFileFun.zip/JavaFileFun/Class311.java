public class Class311{
	public static String getString(){
		return "";
	}
}


