public class Class261{
	public static String getString(){
		return "";
	}
}


