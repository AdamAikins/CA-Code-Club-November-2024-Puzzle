public class Class400{
	public static String getString(){
		return "";
	}
}


