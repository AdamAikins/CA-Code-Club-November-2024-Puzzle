public class Class334{
	public static String getString(){
		return "";
	}
}


