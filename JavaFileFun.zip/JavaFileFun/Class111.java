public class Class111{
	public static String getString(){
		return "";
	}
}


