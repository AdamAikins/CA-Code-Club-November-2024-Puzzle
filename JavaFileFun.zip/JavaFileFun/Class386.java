public class Class386{
	public static String getString(){
		return "";
	}
}


