public class Class023{
	public static String getString(){
		return "";
	}
}


