public class Class364{
	public static String getString(){
		return "";
	}
}


