public class Class357{
	public static String getString(){
		return "";
	}
}


