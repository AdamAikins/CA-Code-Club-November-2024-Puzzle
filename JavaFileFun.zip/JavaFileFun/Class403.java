public class Class403{
	public static String getString(){
		return "";
	}
}


