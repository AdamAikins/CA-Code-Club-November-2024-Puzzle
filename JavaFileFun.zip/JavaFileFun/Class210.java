public class Class210{
	public static String getString(){
		return "";
	}
}


