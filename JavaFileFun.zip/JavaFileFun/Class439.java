public class Class439{
	public static String getString(){
		return "";
	}
}


