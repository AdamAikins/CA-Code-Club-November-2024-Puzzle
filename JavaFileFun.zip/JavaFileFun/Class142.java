public class Class142{
	public static String getString(){
		return "";
	}
}


