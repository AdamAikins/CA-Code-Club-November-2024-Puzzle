public class Class358{
	public static String getString(){
		return "";
	}
}


