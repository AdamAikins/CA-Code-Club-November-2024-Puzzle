public class Class001{
	public static String getString(){
		return "";
	}
}


