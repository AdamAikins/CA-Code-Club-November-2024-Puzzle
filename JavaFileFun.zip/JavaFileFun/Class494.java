public class Class494{
	public static String getString(){
		return "";
	}
}


