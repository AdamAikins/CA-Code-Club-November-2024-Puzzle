public class Class225{
	public static String getString(){
		return "";
	}
}


