public class Class464{
	public static String getString(){
		return "";
	}
}


