public class Class205{
	public static String getString(){
		return "";
	}
}


