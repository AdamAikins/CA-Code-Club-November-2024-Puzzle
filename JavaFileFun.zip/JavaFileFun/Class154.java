public class Class154{
	public static String getString(){
		return "";
	}
}


