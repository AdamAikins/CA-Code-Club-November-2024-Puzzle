public class Class382{
	public static String getString(){
		return "";
	}
}


