public class Class211{
	public static String getString(){
		return "";
	}
}


