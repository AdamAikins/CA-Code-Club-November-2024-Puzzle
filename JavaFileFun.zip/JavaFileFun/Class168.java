public class Class168{
	public static String getString(){
		return "";
	}
}


