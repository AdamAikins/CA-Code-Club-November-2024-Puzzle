public class Class159{
	public static String getString(){
		return "";
	}
}


