public class Class369{
	public static String getString(){
		return "";
	}
}


