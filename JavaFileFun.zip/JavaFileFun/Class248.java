public class Class248{
	public static String getString(){
		return "";
	}
}


