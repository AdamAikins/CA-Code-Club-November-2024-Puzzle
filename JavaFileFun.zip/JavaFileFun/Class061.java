public class Class061{
	public static String getString(){
		return "";
	}
}


