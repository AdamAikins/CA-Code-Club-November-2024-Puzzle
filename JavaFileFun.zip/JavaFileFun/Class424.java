public class Class424{
	public static String getString(){
		return "";
	}
}


