public class Class101{
	public static String getString(){
		return "";
	}
}


