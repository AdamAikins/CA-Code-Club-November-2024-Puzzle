public class Class014{
	public static String getString(){
		return "";
	}
}


