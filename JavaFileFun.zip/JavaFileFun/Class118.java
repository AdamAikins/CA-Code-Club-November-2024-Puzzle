public class Class118{
	public static String getString(){
		return "";
	}
}


