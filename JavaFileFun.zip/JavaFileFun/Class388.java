public class Class388{
	public static String getString(){
		return "";
	}
}


