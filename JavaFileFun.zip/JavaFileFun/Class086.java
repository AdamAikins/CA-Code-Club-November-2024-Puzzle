public class Class086{
	public static String getString(){
		return "";
	}
}


