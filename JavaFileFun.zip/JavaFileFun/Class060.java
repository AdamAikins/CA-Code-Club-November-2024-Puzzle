public class Class060{
	public static String getString(){
		return "";
	}
}


