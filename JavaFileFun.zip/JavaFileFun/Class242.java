public class Class242{
	public static String getString(){
		return "";
	}
}


