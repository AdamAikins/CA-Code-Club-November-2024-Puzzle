public class Class281{
	public static String getString(){
		return "";
	}
}


