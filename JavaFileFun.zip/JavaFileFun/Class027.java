public class Class027{
	public static String getString(){
		return "";
	}
}


