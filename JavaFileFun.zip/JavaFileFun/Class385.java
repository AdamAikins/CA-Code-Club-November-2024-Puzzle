public class Class385{
	public static String getString(){
		return "";
	}
}


