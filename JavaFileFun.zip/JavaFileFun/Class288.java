public class Class288{
	public static String getString(){
		return "";
	}
}


