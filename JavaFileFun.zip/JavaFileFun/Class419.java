public class Class419{
	public static String getString(){
		return "";
	}
}


