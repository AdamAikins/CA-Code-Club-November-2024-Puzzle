public class Class029{
	public static String getString(){
		return "";
	}
}


