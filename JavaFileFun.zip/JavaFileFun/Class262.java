public class Class262{
	public static String getString(){
		return "";
	}
}


