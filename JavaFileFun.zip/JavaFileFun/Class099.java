public class Class099{
	public static String getString(){
		return "";
	}
}


