public class Class326{
	public static String getString(){
		return "";
	}
}


