public class Class075{
	public static String getString(){
		return "";
	}
}


