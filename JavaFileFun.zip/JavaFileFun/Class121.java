public class Class121{
	public static String getString(){
		return "";
	}
}


