public class Class416{
	public static String getString(){
		return "";
	}
}


