public class Class441{
	public static String getString(){
		return "";
	}
}


