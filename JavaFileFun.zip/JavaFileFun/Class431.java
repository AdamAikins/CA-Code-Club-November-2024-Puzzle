public class Class431{
	public static String getString(){
		return "";
	}
}


