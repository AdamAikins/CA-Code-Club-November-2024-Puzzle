public class Class475{
	public static String getString(){
		return "";
	}
}


