public class Class283{
	public static String getString(){
		return "";
	}
}


