public class Class361{
	public static String getString(){
		return "";
	}
}


