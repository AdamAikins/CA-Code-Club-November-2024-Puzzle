public class Class347{
	public static String getString(){
		return "";
	}
}


