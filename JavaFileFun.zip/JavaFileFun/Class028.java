public class Class028{
	public static String getString(){
		return "";
	}
}


