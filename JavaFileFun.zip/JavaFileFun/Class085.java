public class Class085{
	public static String getString(){
		return "";
	}
}


