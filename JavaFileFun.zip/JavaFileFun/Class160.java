public class Class160{
	public static String getString(){
		return "";
	}
}


