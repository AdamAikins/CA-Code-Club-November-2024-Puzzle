public class Class498{
	public static String getString(){
		return "";
	}
}


