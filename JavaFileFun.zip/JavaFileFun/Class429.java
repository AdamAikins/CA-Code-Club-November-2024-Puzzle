public class Class429{
	public static String getString(){
		return "";
	}
}


