public class Class120{
	public static String getString(){
		return "";
	}
}


