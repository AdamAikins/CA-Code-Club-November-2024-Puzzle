public class Class141{
	public static String getString(){
		return "";
	}
}


