public class Class372{
	public static String getString(){
		return "";
	}
}


