public class Class158{
	public static String getString(){
		return "";
	}
}


