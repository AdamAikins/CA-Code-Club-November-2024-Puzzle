public class Class143{
	public static String getString(){
		return "";
	}
}


