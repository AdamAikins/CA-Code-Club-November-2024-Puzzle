public class Class463{
	public static String getString(){
		return "";
	}
}


