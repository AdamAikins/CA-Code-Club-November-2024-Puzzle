public class Class279{
	public static String getString(){
		return "";
	}
}


