public class Class164{
	public static String getString(){
		return "";
	}
}


