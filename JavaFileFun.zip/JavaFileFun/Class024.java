public class Class024{
	public static String getString(){
		return "";
	}
}


