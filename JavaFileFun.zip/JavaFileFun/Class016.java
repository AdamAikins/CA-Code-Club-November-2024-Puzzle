public class Class016{
	public static String getString(){
		return "";
	}
}


