public class Class217{
	public static String getString(){
		return "";
	}
}


