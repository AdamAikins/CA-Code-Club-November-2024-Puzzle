public class Class226{
	public static String getString(){
		return "";
	}
}


