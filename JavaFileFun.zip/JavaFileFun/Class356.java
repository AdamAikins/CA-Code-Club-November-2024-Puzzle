public class Class356{
	public static String getString(){
		return "";
	}
}


