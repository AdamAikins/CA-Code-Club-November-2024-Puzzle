public class Class145{
	public static String getString(){
		return "";
	}
}


