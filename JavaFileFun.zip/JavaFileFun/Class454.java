public class Class454{
	public static String getString(){
		return "";
	}
}


