public class Class484{
	public static String getString(){
		return "";
	}
}


