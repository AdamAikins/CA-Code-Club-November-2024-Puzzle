public class Class006{
	public static String getString(){
		return "";
	}
}


