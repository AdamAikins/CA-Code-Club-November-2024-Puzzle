public class Class077{
	public static String getString(){
		return "";
	}
}


