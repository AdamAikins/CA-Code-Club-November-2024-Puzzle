public class Class325{
	public static String getString(){
		return "";
	}
}


