public class Class329{
	public static String getString(){
		return "";
	}
}


