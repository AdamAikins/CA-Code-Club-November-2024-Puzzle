public class Class080{
	public static String getString(){
		return "";
	}
}


