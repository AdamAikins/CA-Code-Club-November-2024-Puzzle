public class Class064{
	public static String getString(){
		return "";
	}
}


