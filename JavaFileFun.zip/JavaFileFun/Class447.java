public class Class447{
	public static String getString(){
		return "";
	}
}


