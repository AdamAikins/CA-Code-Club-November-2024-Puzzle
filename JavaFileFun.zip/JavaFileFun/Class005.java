public class Class005{
	public static String getString(){
		return "";
	}
}


