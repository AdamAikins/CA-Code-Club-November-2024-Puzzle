public class Class132{
	public static String getString(){
		return "";
	}
}


