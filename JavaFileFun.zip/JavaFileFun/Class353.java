public class Class353{
	public static String getString(){
		return "";
	}
}


