public class Class446{
	public static String getString(){
		return "";
	}
}


