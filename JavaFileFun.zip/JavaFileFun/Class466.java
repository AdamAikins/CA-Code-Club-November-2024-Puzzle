public class Class466{
	public static String getString(){
		return "";
	}
}


