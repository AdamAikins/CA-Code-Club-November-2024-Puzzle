public class Class308{
	public static String getString(){
		return "";
	}
}


