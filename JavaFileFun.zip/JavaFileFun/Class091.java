public class Class091{
	public static String getString(){
		return "";
	}
}


