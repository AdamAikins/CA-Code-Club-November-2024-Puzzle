public class Class087{
	public static String getString(){
		return "";
	}
}


