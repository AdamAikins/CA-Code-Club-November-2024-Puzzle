public class Class151{
	public static String getString(){
		return "";
	}
}


