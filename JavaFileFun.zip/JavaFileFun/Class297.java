public class Class297{
	public static String getString(){
		return "";
	}
}


