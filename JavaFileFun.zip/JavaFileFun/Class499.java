public class Class499{
	public static String getString(){
		return "";
	}
}


