public class Class478{
	public static String getString(){
		return "";
	}
}


