public class Class274{
	public static String getString(){
		return "";
	}
}


