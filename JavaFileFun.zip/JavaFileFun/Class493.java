public class Class493{
	public static String getString(){
		return "";
	}
}


