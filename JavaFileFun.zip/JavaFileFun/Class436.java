public class Class436{
	public static String getString(){
		return "";
	}
}


