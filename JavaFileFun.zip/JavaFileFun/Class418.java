public class Class418{
	public static String getString(){
		return "";
	}
}


