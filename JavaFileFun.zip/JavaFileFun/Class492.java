public class Class492{
	public static String getString(){
		return "";
	}
}


