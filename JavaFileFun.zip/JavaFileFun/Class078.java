public class Class078{
	public static String getString(){
		return "";
	}
}


