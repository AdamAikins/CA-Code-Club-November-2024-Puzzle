public class Class043{
	public static String getString(){
		return "";
	}
}


