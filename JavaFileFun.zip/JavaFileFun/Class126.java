public class Class126{
	public static String getString(){
		return "";
	}
}


