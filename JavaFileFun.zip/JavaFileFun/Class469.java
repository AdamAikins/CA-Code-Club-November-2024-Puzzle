public class Class469{
	public static String getString(){
		return "";
	}
}


