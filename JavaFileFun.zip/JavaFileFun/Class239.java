public class Class239{
	public static String getString(){
		return "";
	}
}


