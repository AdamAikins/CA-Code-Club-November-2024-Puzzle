public class Class306{
	public static String getString(){
		return "";
	}
}


