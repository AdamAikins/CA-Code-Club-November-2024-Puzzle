public class Class323{
	public static String getString(){
		return "";
	}
}


