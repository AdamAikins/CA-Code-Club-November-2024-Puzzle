public class Class319{
	public static String getString(){
		return "";
	}
}


