public class Class093{
	public static String getString(){
		return "";
	}
}


