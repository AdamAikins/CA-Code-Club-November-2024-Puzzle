public class Class241{
	public static String getString(){
		return "";
	}
}


