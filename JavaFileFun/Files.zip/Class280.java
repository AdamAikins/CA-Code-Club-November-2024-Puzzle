public class Class280{
	public static String getString(){
		return "";
	}
}


