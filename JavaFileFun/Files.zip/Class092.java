public class Class092{
	public static String getString(){
		return "";
	}
}


