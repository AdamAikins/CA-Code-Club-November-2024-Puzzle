public class Class278{
	public static String getString(){
		return "";
	}
}


