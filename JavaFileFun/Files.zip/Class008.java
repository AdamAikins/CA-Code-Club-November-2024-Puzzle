public class Class008{
	public static String getString(){
		return "";
	}
}


