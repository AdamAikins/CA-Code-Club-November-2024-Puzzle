public class Class224{
	public static String getString(){
		return "";
	}
}


