public class Class032{
	public static String getString(){
		return "";
	}
}


