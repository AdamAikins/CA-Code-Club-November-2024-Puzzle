public class Class287{
	public static String getString(){
		return "";
	}
}


