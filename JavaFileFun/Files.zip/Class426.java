public class Class426{
	public static String getString(){
		return "";
	}
}


