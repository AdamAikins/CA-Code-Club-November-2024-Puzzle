public class Class169{
	public static String getString(){
		return "";
	}
}


