public class Class031{
	public static String getString(){
		return "";
	}
}


