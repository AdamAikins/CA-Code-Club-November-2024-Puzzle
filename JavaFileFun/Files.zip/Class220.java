public class Class220{
	public static String getString(){
		return "";
	}
}


