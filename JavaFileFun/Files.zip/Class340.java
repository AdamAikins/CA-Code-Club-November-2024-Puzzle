public class Class340{
	public static String getString(){
		return "";
	}
}


