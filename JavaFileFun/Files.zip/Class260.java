public class Class260{
	public static String getString(){
		return "";
	}
}


