public class Class182{
	public static String getString(){
		return "";
	}
}


