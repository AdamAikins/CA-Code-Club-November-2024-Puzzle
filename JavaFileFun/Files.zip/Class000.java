public class Class000{
	public static String getString(){
		return "";
	}
}


