public class Class272{
	public static String getString(){
		return "";
	}
}


