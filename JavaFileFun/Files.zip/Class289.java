public class Class289{
	public static String getString(){
		return "";
	}
}


