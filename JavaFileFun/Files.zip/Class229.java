public class Class229{
	public static String getString(){
		return "";
	}
}


