public class Class090{
	public static String getString(){
		return "";
	}
}


