public class Class130{
	public static String getString(){
		return "";
	}
}


