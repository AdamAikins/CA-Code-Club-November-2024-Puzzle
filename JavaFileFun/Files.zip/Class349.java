public class Class349{
	public static String getString(){
		return "";
	}
}


