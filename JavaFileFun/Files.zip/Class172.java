public class Class172{
	public static String getString(){
		return "";
	}
}


