public class Class094{
	public static String getString(){
		return "";
	}
}


