public class Class399{
	public static String getString(){
		return "";
	}
}


