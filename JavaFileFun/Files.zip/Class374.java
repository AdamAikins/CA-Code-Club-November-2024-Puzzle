public class Class374{
	public static String getString(){
		return "";
	}
}


