public class Class247{
	public static String getString(){
		return "";
	}
}


