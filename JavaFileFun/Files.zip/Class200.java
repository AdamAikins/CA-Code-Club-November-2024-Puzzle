public class Class200{
	public static String getString(){
		return "";
	}
}


