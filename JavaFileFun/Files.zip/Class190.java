public class Class190{
	public static String getString(){
		return "";
	}
}


