public class Class371{
	public static String getString(){
		return "";
	}
}


