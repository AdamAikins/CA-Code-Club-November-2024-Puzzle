public class Class391{
	public static String getString(){
		return "";
	}
}


