public class Class376{
	public static String getString(){
		return "";
	}
}


