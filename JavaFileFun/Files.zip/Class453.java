public class Class453{
	public static String getString(){
		return "";
	}
}


