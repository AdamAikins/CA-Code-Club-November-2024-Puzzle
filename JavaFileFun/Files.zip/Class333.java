public class Class333{
	public static String getString(){
		return "";
	}
}


