public class Class183{
	public static String getString(){
		return "";
	}
}


