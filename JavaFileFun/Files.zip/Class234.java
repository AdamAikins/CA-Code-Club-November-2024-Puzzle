public class Class234{
	public static String getString(){
		return "";
	}
}


