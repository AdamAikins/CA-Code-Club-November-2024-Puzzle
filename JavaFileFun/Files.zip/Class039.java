public class Class039{
	public static String getString(){
		return "";
	}
}


