public class Class138{
	public static String getString(){
		return "";
	}
}


