public class Class140{
	public static String getString(){
		return "";
	}
}


