public class Class277{
	public static String getString(){
		return "";
	}
}


