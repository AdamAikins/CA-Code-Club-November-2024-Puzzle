public class Class222{
	public static String getString(){
		return "";
	}
}


