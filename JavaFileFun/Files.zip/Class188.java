public class Class188{
	public static String getString(){
		return "";
	}
}


