public class Class076{
	public static String getString(){
		return "";
	}
}


