public class Class491{
	public static String getString(){
		return "";
	}
}


