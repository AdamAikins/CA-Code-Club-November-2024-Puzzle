public class Class136{
	public static String getString(){
		return "";
	}
}


