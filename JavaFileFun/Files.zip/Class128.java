public class Class128{
	public static String getString(){
		return "";
	}
}


