public class Class089{
	public static String getString(){
		return "";
	}
}


