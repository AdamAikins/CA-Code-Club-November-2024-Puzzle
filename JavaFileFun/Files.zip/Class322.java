public class Class322{
	public static String getString(){
		return "";
	}
}


