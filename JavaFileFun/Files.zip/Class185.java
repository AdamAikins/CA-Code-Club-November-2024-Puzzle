public class Class185{
	public static String getString(){
		return "";
	}
}


