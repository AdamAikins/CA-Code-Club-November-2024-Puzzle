public class Class212{
	public static String getString(){
		return "";
	}
}


