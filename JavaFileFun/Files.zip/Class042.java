public class Class042{
	public static String getString(){
		return "";
	}
}


