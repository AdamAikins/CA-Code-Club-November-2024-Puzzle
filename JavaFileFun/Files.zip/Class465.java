public class Class465{
	public static String getString(){
		return "";
	}
}


