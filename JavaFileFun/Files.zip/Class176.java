public class Class176{
	public static String getString(){
		return "";
	}
}


