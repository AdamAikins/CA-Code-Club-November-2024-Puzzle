public class Class131{
	public static String getString(){
		return "";
	}
}


