public class Class139{
	public static String getString(){
		return "";
	}
}


