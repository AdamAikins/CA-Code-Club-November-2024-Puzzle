public class Class216{
	public static String getString(){
		return "";
	}
}


