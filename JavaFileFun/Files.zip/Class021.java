public class Class021{
	public static String getString(){
		return "";
	}
}


