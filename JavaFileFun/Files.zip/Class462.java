public class Class462{
	public static String getString(){
		return "";
	}
}


