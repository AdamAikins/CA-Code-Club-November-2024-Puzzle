public class Class299{
	public static String getString(){
		return "";
	}
}


