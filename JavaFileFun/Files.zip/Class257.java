public class Class257{
	public static String getString(){
		return "";
	}
}


