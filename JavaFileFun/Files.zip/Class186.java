public class Class186{
	public static String getString(){
		return "";
	}
}


