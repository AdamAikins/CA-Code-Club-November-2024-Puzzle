public class Class231{
	public static String getString(){
		return "";
	}
}


