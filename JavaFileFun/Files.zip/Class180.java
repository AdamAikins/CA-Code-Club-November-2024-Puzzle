public class Class180{
	public static String getString(){
		return "";
	}
}


