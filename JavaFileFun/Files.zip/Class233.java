public class Class233{
	public static String getString(){
		return "";
	}
}


