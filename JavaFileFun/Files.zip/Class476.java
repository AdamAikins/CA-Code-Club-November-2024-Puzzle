public class Class476{
	public static String getString(){
		return "";
	}
}


