public class Class269{
	public static String getString(){
		return "";
	}
}


