public class Class342{
	public static String getString(){
		return "";
	}
}


