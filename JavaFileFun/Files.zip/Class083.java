public class Class083{
	public static String getString(){
		return "";
	}
}


