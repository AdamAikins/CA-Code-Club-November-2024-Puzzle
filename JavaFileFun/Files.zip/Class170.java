public class Class170{
	public static String getString(){
		return "";
	}
}


