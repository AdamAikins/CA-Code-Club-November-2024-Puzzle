public class Class166{
	public static String getString(){
		return "";
	}
}


