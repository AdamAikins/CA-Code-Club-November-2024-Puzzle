public class Class458{
	public static String getString(){
		return "";
	}
}


