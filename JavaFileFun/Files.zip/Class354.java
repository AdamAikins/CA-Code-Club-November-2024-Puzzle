public class Class354{
	public static String getString(){
		return "";
	}
}


