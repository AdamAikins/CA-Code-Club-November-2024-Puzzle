public class Class108{
	public static String getString(){
		return "";
	}
}


