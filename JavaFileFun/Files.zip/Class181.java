public class Class181{
	public static String getString(){
		return "";
	}
}


