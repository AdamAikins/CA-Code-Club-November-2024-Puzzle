public class Class318{
	public static String getString(){
		return "";
	}
}


