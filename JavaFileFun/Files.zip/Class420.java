public class Class420{
	public static String getString(){
		return "";
	}
}


