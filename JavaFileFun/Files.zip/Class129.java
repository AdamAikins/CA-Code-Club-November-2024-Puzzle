public class Class129{
	public static String getString(){
		return "";
	}
}


