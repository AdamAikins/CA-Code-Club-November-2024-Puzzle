public class Class327{
	public static String getString(){
		return "";
	}
}


