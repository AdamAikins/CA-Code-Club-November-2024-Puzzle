public class Class079{
	public static String getString(){
		return "";
	}
}


