public class Class335{
	public static String getString(){
		return "";
	}
}


