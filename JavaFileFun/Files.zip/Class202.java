public class Class202{
	public static String getString(){
		return "";
	}
}


