public class Class069{
	public static String getString(){
		return "";
	}
}


