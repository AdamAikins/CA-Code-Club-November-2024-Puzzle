public class Class150{
	public static String getString(){
		return "";
	}
}


