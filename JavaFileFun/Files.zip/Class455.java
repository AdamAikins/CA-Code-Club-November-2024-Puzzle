public class Class455{
	public static String getString(){
		return "";
	}
}


