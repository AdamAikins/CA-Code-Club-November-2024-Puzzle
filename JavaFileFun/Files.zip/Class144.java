public class Class144{
	public static String getString(){
		return "";
	}
}


