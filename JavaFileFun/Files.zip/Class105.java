public class Class105{
	public static String getString(){
		return "";
	}
}


