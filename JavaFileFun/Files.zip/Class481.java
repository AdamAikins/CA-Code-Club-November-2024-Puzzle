public class Class481{
	public static String getString(){
		return "";
	}
}


