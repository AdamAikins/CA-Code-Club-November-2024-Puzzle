public class Class417{
	public static String getString(){
		return "";
	}
}


