public class Class396{
	public static String getString(){
		return "";
	}
}


