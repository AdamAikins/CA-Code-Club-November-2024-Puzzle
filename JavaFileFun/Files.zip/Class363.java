public class Class363{
	public static String getString(){
		return "";
	}
}


