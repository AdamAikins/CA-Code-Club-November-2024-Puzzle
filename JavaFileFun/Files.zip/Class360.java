public class Class360{
	public static String getString(){
		return "";
	}
}


