public class Class230{
	public static String getString(){
		return "";
	}
}


