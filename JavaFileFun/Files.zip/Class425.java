public class Class425{
	public static String getString(){
		return "";
	}
}


