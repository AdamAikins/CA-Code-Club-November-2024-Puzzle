public class Class488{
	public static String getString(){
		return "";
	}
}


