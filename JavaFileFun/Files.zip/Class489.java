public class Class489{
	public static String getString(){
		return "";
	}
}


