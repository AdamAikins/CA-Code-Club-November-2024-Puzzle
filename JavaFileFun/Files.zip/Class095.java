public class Class095{
	public static String getString(){
		return "";
	}
}


