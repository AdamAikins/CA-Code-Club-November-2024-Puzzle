public class Class304{
	public static String getString(){
		return "";
	}
}


