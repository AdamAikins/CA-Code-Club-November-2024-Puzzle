public class Class179{
	public static String getString(){
		return "";
	}
}


