public class Class199{
	public static String getString(){
		return "";
	}
}


