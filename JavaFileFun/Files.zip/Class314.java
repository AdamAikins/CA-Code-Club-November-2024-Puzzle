public class Class314{
	public static String getString(){
		return "";
	}
}


