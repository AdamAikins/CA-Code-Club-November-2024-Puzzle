public class Class317{
	public static String getString(){
		return "";
	}
}


