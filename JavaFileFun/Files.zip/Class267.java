public class Class267{
	public static String getString(){
		return "";
	}
}


