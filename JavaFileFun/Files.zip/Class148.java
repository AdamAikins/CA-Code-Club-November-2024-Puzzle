public class Class148{
	public static String getString(){
		return "";
	}
}


