public class Class313{
	public static String getString(){
		return "";
	}
}


