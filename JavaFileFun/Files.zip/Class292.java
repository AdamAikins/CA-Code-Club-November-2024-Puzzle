public class Class292{
	public static String getString(){
		return "";
	}
}


