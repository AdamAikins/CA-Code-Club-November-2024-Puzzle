public class Class167{
	public static String getString(){
		return "";
	}
}


