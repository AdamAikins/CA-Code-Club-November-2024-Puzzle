public class Class153{
	public static String getString(){
		return "";
	}
}


