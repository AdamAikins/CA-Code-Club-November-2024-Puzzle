public class Class050{
	public static String getString(){
		return "";
	}
}


