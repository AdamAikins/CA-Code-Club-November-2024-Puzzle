public class Class052{
	public static String getString(){
		return "";
	}
}


