public class Class479{
	public static String getString(){
		return "";
	}
}


