public class Class421{
	public static String getString(){
		return "";
	}
}


