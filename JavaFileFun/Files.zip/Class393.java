public class Class393{
	public static String getString(){
		return "";
	}
}


