public class Class359{
	public static String getString(){
		return "";
	}
}


