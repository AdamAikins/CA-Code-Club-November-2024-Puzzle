public class Class125{
	public static String getString(){
		return "";
	}
}


