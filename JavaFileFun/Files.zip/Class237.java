public class Class237{
	public static String getString(){
		return "";
	}
}


