public class Class472{
	public static String getString(){
		return "";
	}
}


