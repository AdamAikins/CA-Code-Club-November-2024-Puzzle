public class Class082{
	public static String getString(){
		return "";
	}
}


