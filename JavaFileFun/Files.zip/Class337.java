public class Class337{
	public static String getString(){
		return "";
	}
}


