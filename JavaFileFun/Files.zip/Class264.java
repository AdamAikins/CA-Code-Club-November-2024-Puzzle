public class Class264{
	public static String getString(){
		return "";
	}
}


