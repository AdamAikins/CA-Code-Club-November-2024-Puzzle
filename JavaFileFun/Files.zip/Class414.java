public class Class414{
	public static String getString(){
		return "";
	}
}


