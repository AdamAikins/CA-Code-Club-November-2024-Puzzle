public class Class258{
	public static String getString(){
		return "";
	}
}


