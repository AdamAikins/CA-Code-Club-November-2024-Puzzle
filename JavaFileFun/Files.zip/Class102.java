public class Class102{
	public static String getString(){
		return "";
	}
}


