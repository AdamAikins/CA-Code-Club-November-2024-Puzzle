public class Class302{
	public static String getString(){
		return "";
	}
}


