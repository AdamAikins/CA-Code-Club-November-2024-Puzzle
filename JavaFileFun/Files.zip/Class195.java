public class Class195{
	public static String getString(){
		return "";
	}
}


