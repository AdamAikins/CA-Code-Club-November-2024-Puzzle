public class Class073{
	public static String getString(){
		return "";
	}
}


