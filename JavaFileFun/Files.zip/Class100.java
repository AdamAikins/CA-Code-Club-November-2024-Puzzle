public class Class100{
	public static String getString(){
		return "";
	}
}


