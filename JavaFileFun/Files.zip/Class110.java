public class Class110{
	public static String getString(){
		return "";
	}
}


