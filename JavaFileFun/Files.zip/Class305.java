public class Class305{
	public static String getString(){
		return "";
	}
}


