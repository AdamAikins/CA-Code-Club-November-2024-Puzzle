public class Class290{
	public static String getString(){
		return "";
	}
}


