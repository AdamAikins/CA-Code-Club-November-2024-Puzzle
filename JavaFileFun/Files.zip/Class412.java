public class Class412{
	public static String getString(){
		return "I like eating hotdogs";
	}
}


