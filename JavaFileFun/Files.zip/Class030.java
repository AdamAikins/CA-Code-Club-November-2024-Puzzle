public class Class030{
	public static String getString(){
		return "";
	}
}


