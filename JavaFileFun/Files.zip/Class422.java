public class Class422{
	public static String getString(){
		return "";
	}
}


