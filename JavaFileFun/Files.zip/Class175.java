public class Class175{
	public static String getString(){
		return "";
	}
}


