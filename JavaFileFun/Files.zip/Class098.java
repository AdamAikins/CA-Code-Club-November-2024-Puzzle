public class Class098{
	public static String getString(){
		return "";
	}
}


