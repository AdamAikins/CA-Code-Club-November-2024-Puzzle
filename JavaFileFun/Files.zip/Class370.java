public class Class370{
	public static String getString(){
		return "";
	}
}


