public class Class449{
	public static String getString(){
		return "";
	}
}


