public class Class284{
	public static String getString(){
		return "";
	}
}


