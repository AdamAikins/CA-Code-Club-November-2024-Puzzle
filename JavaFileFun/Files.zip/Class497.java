public class Class497{
	public static String getString(){
		return "";
	}
}


