public class Class106{
	public static String getString(){
		return "";
	}
}


