public class Class107{
	public static String getString(){
		return "";
	}
}


