public class Class070{
	public static String getString(){
		return "";
	}
}


