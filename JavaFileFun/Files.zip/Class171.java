public class Class171{
	public static String getString(){
		return "";
	}
}


