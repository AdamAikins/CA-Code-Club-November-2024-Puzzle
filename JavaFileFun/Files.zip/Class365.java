public class Class365{
	public static String getString(){
		return "";
	}
}


