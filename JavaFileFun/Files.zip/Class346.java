public class Class346{
	public static String getString(){
		return "";
	}
}


