public class Class152{
	public static String getString(){
		return "";
	}
}


