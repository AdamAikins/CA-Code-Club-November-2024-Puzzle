public class Class486{
	public static String getString(){
		return "";
	}
}


