public class Class240{
	public static String getString(){
		return "";
	}
}


