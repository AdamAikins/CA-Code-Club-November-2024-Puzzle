public class Class373{
	public static String getString(){
		return "";
	}
}


