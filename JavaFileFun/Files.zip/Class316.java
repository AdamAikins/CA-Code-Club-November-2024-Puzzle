public class Class316{
	public static String getString(){
		return "";
	}
}


