public class Class367{
	public static String getString(){
		return "";
	}
}


