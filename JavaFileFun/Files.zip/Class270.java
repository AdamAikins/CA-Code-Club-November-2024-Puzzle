public class Class270{
	public static String getString(){
		return "";
	}
}


