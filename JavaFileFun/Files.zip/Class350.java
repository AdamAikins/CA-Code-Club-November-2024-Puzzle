public class Class350{
	public static String getString(){
		return "";
	}
}


