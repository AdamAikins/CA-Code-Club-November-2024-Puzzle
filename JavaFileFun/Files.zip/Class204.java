public class Class204{
	public static String getString(){
		return "";
	}
}


