public class Class194{
	public static String getString(){
		return "";
	}
}


