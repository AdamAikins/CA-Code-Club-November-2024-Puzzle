public class Class482{
	public static String getString(){
		return "";
	}
}


