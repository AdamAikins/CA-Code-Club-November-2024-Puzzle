public class Class215{
	public static String getString(){
		return "";
	}
}


