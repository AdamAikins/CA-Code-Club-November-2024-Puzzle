public class Class045{
	public static String getString(){
		return "";
	}
}


