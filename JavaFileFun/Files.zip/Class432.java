public class Class432{
	public static String getString(){
		return "";
	}
}


