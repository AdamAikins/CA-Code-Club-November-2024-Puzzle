public class Class321{
	public static String getString(){
		return "";
	}
}


