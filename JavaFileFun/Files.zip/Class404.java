public class Class404{
	public static String getString(){
		return "";
	}
}


