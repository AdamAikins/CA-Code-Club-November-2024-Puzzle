public class Class445{
	public static String getString(){
		return "";
	}
}


