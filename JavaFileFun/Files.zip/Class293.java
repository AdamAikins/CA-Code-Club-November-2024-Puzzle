public class Class293{
	public static String getString(){
		return "";
	}
}


