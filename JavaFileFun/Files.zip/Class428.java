public class Class428{
	public static String getString(){
		return "";
	}
}


