public class Class041{
	public static String getString(){
		return "";
	}
}


