public class Class156{
	public static String getString(){
		return "";
	}
}


