public class Class235{
	public static String getString(){
		return "";
	}
}


