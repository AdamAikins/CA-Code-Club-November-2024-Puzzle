public class Class406{
	public static String getString(){
		return "";
	}
}


