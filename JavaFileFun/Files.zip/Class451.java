public class Class451{
	public static String getString(){
		return "";
	}
}


