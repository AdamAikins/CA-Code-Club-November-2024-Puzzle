public class Class004{
	public static String getString(){
		return "";
	}
}


