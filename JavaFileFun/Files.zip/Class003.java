public class Class003{
	public static String getString(){
		return "";
	}
}


