public class Class103{
	public static String getString(){
		return "";
	}
}


