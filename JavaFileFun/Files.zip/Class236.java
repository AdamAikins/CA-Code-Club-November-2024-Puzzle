public class Class236{
	public static String getString(){
		return "";
	}
}


