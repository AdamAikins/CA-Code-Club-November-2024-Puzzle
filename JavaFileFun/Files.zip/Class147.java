public class Class147{
	public static String getString(){
		return "";
	}
}


