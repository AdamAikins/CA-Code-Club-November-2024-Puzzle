public class Class122{
	public static String getString(){
		return "";
	}
}


