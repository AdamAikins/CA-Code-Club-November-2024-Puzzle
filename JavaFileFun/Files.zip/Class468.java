public class Class468{
	public static String getString(){
		return "";
	}
}


