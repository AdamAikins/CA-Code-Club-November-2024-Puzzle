public class Class134{
	public static String getString(){
		return "";
	}
}


