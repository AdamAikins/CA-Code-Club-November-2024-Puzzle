public class Class196{
	public static String getString(){
		return "";
	}
}


