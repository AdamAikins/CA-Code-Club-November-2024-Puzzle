public class Class135{
	public static String getString(){
		return "";
	}
}


