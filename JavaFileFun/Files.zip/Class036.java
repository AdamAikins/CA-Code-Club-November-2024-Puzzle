public class Class036{
	public static String getString(){
		return "";
	}
}


