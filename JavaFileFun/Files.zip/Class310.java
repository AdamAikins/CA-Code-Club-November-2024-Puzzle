public class Class310{
	public static String getString(){
		return "";
	}
}


