public class Class072{
	public static String getString(){
		return "";
	}
}


