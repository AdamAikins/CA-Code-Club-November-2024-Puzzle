public class Class096{
	public static String getString(){
		return "";
	}
}


