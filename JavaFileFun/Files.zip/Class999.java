public class Class999{
	public static String getString(){
		return "";
	}
}


