public class Class384{
	public static String getString(){
		return "";
	}
}


