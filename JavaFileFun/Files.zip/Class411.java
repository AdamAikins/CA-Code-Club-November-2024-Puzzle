public class Class411{
	public static String getString(){
		return "";
	}
}


