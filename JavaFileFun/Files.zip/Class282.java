public class Class282{
	public static String getString(){
		return "";
	}
}


