public class Class345{
	public static String getString(){
		return "";
	}
}


