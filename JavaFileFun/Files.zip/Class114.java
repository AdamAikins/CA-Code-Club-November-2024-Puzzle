public class Class114{
	public static String getString(){
		return "";
	}
}


