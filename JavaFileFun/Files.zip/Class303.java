public class Class303{
	public static String getString(){
		return "";
	}
}


