public class Class352{
	public static String getString(){
		return "";
	}
}


