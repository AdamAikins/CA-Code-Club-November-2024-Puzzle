public class Class485{
	public static String getString(){
		return "";
	}
}


