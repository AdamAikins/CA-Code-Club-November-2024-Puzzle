public class Class320{
	public static String getString(){
		return "";
	}
}


