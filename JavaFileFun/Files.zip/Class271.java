public class Class271{
	public static String getString(){
		return "";
	}
}


