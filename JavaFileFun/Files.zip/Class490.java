public class Class490{
	public static String getString(){
		return "";
	}
}


