public class Class149{
	public static String getString(){
		return "";
	}
}


