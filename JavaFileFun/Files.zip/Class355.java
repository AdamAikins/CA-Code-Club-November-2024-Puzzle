public class Class355{
	public static String getString(){
		return "";
	}
}


