public class Class309{
	public static String getString(){
		return "";
	}
}


