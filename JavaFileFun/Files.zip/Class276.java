public class Class276{
	public static String getString(){
		return "";
	}
}


