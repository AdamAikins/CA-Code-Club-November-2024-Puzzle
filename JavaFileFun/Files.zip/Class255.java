public class Class255{
	public static String getString(){
		return "";
	}
}


