public class Class296{
	public static String getString(){
		return "";
	}
}


