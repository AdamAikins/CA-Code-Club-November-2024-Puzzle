public class Class467{
	public static String getString(){
		return "";
	}
}


