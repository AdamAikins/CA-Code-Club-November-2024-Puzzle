public class Class301{
	public static String getString(){
		return "";
	}
}


