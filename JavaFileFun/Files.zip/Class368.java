public class Class368{
	public static String getString(){
		return "";
	}
}


