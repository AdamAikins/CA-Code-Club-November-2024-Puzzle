public class Class291{
	public static String getString(){
		return "";
	}
}


