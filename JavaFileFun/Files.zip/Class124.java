public class Class124{
	public static String getString(){
		return "";
	}
}


