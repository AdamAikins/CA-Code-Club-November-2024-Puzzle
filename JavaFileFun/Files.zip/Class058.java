public class Class058{
	public static String getString(){
		return "";
	}
}


