public class Class408{
	public static String getString(){
		return "";
	}
}


