public class Class298{
	public static String getString(){
		return "";
	}
}


