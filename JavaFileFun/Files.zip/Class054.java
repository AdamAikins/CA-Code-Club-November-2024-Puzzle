public class Class054{
	public static String getString(){
		return "";
	}
}


