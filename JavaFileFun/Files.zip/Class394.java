public class Class394{
	public static String getString(){
		return "";
	}
}


