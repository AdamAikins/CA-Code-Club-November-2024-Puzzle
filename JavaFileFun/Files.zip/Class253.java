public class Class253{
	public static String getString(){
		return "";
	}
}


