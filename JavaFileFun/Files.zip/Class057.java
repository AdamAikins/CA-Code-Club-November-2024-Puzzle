public class Class057{
	public static String getString(){
		return "";
	}
}


