public class Class221{
	public static String getString(){
		return "";
	}
}


