public class Class055{
	public static String getString(){
		return "";
	}
}


