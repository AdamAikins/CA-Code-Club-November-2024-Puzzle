public class Class434{
	public static String getString(){
		return "";
	}
}


