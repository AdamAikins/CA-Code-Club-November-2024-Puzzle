public class Class275{
	public static String getString(){
		return "";
	}
}


