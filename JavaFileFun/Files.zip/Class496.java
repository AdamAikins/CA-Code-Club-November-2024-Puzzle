public class Class496{
	public static String getString(){
		return "";
	}
}


