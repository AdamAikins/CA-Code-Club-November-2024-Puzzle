public class Class113{
	public static String getString(){
		return "";
	}
}


