public class Class286{
	public static String getString(){
		return "";
	}
}


