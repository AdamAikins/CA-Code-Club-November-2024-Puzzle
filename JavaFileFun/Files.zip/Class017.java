public class Class017{
	public static String getString(){
		return "";
	}
}


