public class Class444{
	public static String getString(){
		return "";
	}
}


