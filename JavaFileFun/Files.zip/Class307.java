public class Class307{
	public static String getString(){
		return "";
	}
}


