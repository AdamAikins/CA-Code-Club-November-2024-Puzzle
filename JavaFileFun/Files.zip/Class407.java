public class Class407{
	public static String getString(){
		return "";
	}
}


