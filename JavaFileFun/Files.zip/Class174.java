public class Class174{
	public static String getString(){
		return "";
	}
}


