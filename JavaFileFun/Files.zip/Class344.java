public class Class344{
	public static String getString(){
		return "";
	}
}


