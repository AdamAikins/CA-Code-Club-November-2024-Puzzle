public class Class254{
	public static String getString(){
		return "";
	}
}


