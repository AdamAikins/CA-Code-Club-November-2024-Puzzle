public class Class435{
	public static String getString(){
		return "";
	}
}


