public class Class402{
	public static String getString(){
		return "";
	}
}


