public class Class123{
	public static String getString(){
		return "";
	}
}


