public class Class300{
	public static String getString(){
		return "";
	}
}


