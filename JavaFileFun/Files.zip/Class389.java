public class Class389{
	public static String getString(){
		return "";
	}
}


