public class Class191{
	public static String getString(){
		return "";
	}
}


