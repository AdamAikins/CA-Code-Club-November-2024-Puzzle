public class Class206{
	public static String getString(){
		return "";
	}
}


