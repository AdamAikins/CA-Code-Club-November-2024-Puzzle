public class Class495{
	public static String getString(){
		return "";
	}
}


