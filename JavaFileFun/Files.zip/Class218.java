public class Class218{
	public static String getString(){
		return "";
	}
}


