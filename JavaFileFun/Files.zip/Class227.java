public class Class227{
	public static String getString(){
		return "";
	}
}


