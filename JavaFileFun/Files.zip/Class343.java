public class Class343{
	public static String getString(){
		return "";
	}
}


