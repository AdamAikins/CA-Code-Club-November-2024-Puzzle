public class Class184{
	public static String getString(){
		return "";
	}
}


