public class Class063{
	public static String getString(){
		return "";
	}
}


